import discord
import random
import asyncio
import os
from discord.ext import commands
from discord.ext.commands import has_role
from urllib.parse import urlparse
from discord import utils
import json
import time
def get_muterole(message):
    with open("muterole.json", 'r') as f:
        mute = json.load(f)
    role = discord.utils.get(message.guild.roles, name=mute[str(message.guild.id)])
    return role.id
	
class Moderation(commands.Cog):
  def __init__(self, client):
    self.client = client

  
  help_command = commands.DefaultHelpCommand(
    no_category = 'Moderation'
)

  @commands.command(aliases=["strip"], description="Takes all of a user's roles")
  @commands.has_permissions(kick_members=True)  
  async def rolestrip(self, ctx, member:discord.Member):
    await ctx.message.add_reaction('✅')
    role1 = discord.utils.get(ctx.guild.roles, name="Vulture | Role Stripped")
    log = discord.utils.get(ctx.guild.channels, name="🔐・bot-logs")
    await member.edit(roles=[role1])
    embed=discord.Embed(title=f"Member Role Stripped", description="", color=0x51b5d8)
    embed.add_field(name= "Info:" ,value=f"{member.mention} was role stripped by {ctx.author}.", inline=True)
    await log.send(embed=embed)

  @commands.command()
  async def msgcount(self, ctx, channel: discord.TextChannel=None):
      channel = channel or ctx.channel
      count = 0
      async for _ in channel.history(limit=None):
          count += 1
      await ctx.send("There are {} messages in {}".format(count, channel.mention))

      

	
  @commands.command()
  async def baninfo(self, ctx, *, name_or_id):
      '''Check the reason of a ban from the audit logs.'''
      ban = await ctx.get_ban(name_or_id)
      em = discord.Embed()
      em.color = await ctx.get_dominant_color(ban.user.avatar_url)
      em.set_author(name=str(ban.user), icon_url=ban.user.avatar_url)
      em.add_field(name='Reason', value=ban.reason or 'None')
      em.set_thumbnail(url=ban.user.avatar_url)
      em.set_footer(text=f'User ID: {ban.user.id}')
  
      await ctx.send(embed=em)

  
  @commands.command()
  @commands.has_permissions(kick_members=True)  
  async def soundban(self, ctx, member: discord.Member):
    await member.edit(deafen=True)
    await member.edit(mute=True)
    await ctx.channel.send(f'{member.mention} has been banned from hearing.')
    await ctx.message.add_reaction('✅')
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    embed=discord.Embed(title="Soundban", description="A user has been sound banned! ")
    embed.set_author(name="Vulture",icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Sound Banned User", value=f"Sound banned: {member.mention}   ", inline=True)
    embed.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention}", inline=False)
    embed.set_footer(text="HawkEye Services")
    await log.send(embed=embed)
		
  @commands.command()
  @commands.has_permissions(kick_members=True)  
  async def unsoundban(self, ctx, member: discord.Member):
    await member.edit(deafen=False)
    await member.edit(mute=False)
    await ctx.channel.send(f'{member.mention} has the abilty to hear again.')
    await ctx.message.add_reaction('✅')
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    embed=discord.Embed(title="Unsoundban", description="A user has been unsound banned! ")
    embed.set_author(name="Vulture",icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Unsound Banned User", value=f"Unsound banned: {member.mention}   ", inline=True)
    embed.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention}", inline=False)
    embed.set_footer(text="HawkEye Services")
    await log.send(embed=embed)

  def get_muterole(message):
      with open("muterole.json", 'r') as f:
        mute = json.load(f)
      role = discord.utils.get(message.guild.roles, 
  name=mute[str(message.guild.id)])
      return role.id
	

  

  
  @commands.command(aliases=['delay', 'sm','setdelay','setsm'])
  @commands.has_permissions(manage_channels = True)
  async def slowmode(self, ctx, seconds: int):
    await ctx.message.add_reaction('✅')
    await ctx.channel.edit(slowmode_delay=seconds)
    embed=discord.Embed(title="Slowmode", description=f"Slowmode has been activated for {seconds}. Please watch how much you message at a rapid rate before the time increases. ", color=0xffffff)
    embed.set_author(name="HawkEye Services",     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    await ctx.send(embed=embed)
    embed1=discord.Embed(title="Slowmode Activation", description=f"Slowmode has been activated for {seconds} by {ctx.author.mention}.", color=0xffffff)
    embed1.set_author(name="HawkEye Services",     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.add_field(name="Slowmode Time:", value=f"Time: {seconds}", inline=False)
    embed1.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention}", inline=True)
    embed1.set_footer(text="HawkEye Logging")
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    await log.send(embed=embed1)


  

  
  
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(kick_members=True)  
  async def kick(self, ctx, member : discord.Member, *, reason=None):
    await ctx.message.add_reaction('✅')
    embed=discord.Embed(title="Kicked", description=f"You have been removed from {ctx.guild.name} for {reason}. Please understand that you have violated our rules and you have been punished for it. Please next time obey our rules and so all of us can have fun.", color=0xffffff)
    embed.set_author(name=f"HawkEye Services",     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Reason:", value=f"Reason: {reason}", inline=False)
    embed.set_footer(text="HawkEye Services")
    await member.send(embed=embed)
    await member.kick(reason=reason)
    embed1=discord.Embed(title="Kicked", description=f"Member {member.mention} has been kicked by {ctx.author.mention}", color=0xffffff)
    embed1.set_author(name="HawkEye Services",     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.add_field(name="Reason:", value=F"Reason: {reason}", inline=False)
    embed1.add_field(name="Moderator:", value=F"Moderator: {ctx.author.mention}", inline=True)
    embed1.set_footer(text="HawkEye Logging")
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    await log.send(embed=embed1)

  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(kick_members=True)  
  async def setnick(self, ctx, member : discord.Member, nick):
    await member.edit(nick=nick)
    await ctx.channel.send(f'{member.mention}s nickname has been changed.')

  @commands.command(description="Mutes the specified user.")
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(manage_messages=True)
  async def mute(self, ctx, member: discord.Member, *, reason=None):
      await ctx.message.add_reaction('✅')
      guild = ctx.guild
      mutedRole = discord.utils.get(guild.roles, name="Vulture | Muted")
  
      if not mutedRole:
          mutedRole = await guild.create_role(name="Vulture | Muted")
  
          for channel in guild.channels:
              await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_message_history=True, read_messages=False)
      await member.add_roles(mutedRole, reason=reason)
      embed=discord.Embed(title="Muted", description=f"You have been muted for **{reason}**. If this was a mistake please contact a moderator in **{guild.name}**. Please and thank you!")
      embed.set_author(name="Vulture", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.add_field(name="Reason: ", value=f"Reason: {reason}", inline=True)
      embed.add_field(name="Moderator", value=f"Moderator: {ctx.author.mention} ", inline=False)
      embed.set_footer(text="HawkEye Services")
      await member.send(embed=embed)
      log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
      embed=discord.Embed(title="Muted", description="A user has been muted!")
      embed.set_author(name="Vulture", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.add_field(name="Muted User:", value=f"Muted User: {member.mention}", inline=True)
      embed.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention} ", inline=False)
      embed.add_field(name="Reason:", value=f"Reason: {reason}", inline=False),
      embed.set_footer(text="HawkEye Services")
      await log.send(embed=embed)
  
  @commands.command(description="Unmutes a specified user.")
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(manage_messages=True)
  async def unmute(self, ctx, member: discord.Member):
    await ctx.message.add_reaction('✅')
    mutedRole = discord.utils.get(guild.roles, name="Vulture | Muted")
  
    await member.remove_roles(mutedRole)
    embed=discord.Embed(title="Unmuted", description=f"You have been unmuted. Please know that with you being unmuted it means we trust you will obey the rules and not make your mistake again.")
    embed.set_author(name="Vulture", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_footer(text="HawkEye Services")
    await member.send(embed=embed)
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    embed=discord.Embed(title="Unmuted", description="A user has been muted!")
    embed.set_author(name="Vulture", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Unmuted User:", value=f"Unmuted User: {member.mention}", inline=True)
    embed.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention} ", inline=False)
    embed.set_footer(text="HawkEye Services")
    await log.send(embed=embed)
  

  
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(ban_members=True)  
  async def ban(self, ctx, member : discord.Member, *, 
  reason=None):
    embed1=discord.Embed(title="Banned", description=f"You have been banned from {ctx.guild.name} for {reason} by {ctx.author.mention}. Please understand the you have violated our rules and we have punished you. If you believe this is a mistake please contact support <@!460543691703189514>. Please and thank you.", color=0xffffff)
    embed1.set_author(name="HawkEye Services",icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed1.set_footer(text="HawkEye Services | Banned at:")
    await member.send(embed = embed1)
    await member.ban(reason=reason)
    await ctx.message.add_reaction('✅')
    embed=discord.Embed(title="Banned", description=f"User {member.mention} has been banned by {ctx.author}. ", color=0xffffff, timestamp=ctx.message.created_at)
    embed.set_author(name="HawkEye Services", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name=f"User Banned", value=f"User Banned: {member.mention}", inline=False)
    embed.add_field(name=f"Moderator", value=f"Moderator: {ctx.author.mention}", inline=False)
    embed.set_footer(text=f"HawkEye Services | Member banned at: ")
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    await log.send(embed=embed)
  
  
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(ban_members=True)  
  async def unban(self, ctx, user : discord.User):
    guild=ctx.guild
    await ctx.message.add_reaction('✅')
    embed=discord.Embed(title="Unbanned", description=f"User {user.mention} has been unbanned by {ctx.author}. ", color=0xffffff, timestamp=ctx.message.created_at)
    embed.set_author(name="HawkEye Services", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name=f"User Banned", value=f"User Unbanned: {user.mention}", inline=False)
    embed.add_field(name=f"Moderator", value=f"Moderator: {ctx.author.mention}", inline=False)
    embed.set_footer(text=f"HawkEye Services | Member unbanned at: ")
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    await log.send(embed=embed)

  @ban.error
  async def ban_error(ctx, error, amount = 3):
    if isinstance(error,commands.MissingAnyRole):
          await ctx.message.add_reaction('❌')
          await ctx.send(f'You lack permission to use this command.')
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

    return
    if isinstance(error,commands.MissingRequiredArgument):
          await ctx.message.add_reaction('❌')
          await ctx.send(f"You're missing the user name or id!")
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

  @unban.error
  async def unban_error(ctx, error, amount = 3):
    if isinstance(error,commands.MissingAnyRole):
          await ctx.message.add_reaction('❌')
          await ctx.send(f'You lack permission to use this command.')
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

    return
    if isinstance(error,commands.MissingRequiredArgument):
          await ctx.message.add_reaction('❌')
          await ctx.send(f"You're missing the user name or id!")
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)
	
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(kick_members=True)  
  async def voiceban(self, ctx, member: discord.Member):
   await member.edit(mute=True)
   await member.edit(deafen=True)
   await ctx.channel.send(f'{member.mention} has been voice banned.')
  
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(kick_members=True)  
  async def unvoiceban(self, ctx, member: discord.Member):
   await member.edit(mute=False)
   await member.edit(deafen=False)
   await ctx.channel.send(f'{member.mention} has been unvoice banned.')
  
  @commands.command(pass_context=True)
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(kick_members=True)  
  async def addrole(self, ctx, member:discord.Member, *, role:discord.Role = None):
    embed=discord.Embed(title="Role Added", description=f"Role has been given to a member. The moderator is {ctx.author.mention}. Please check down bellow if the role is dangerous ", color=0xf3eded)
    embed.add_field(name="Moderator", value=f"Moderator: {ctx.author.mention}", inline=False)
    embed.add_field(name="Recierver ", value=f"Receiver: {member.mention}", inline=False)
    embed.add_field(name="Permissions:", value=f"Permissions: {role.permissions}", inline=False)
    log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
    await log.send(embed=embed)
    await member.add_roles(role)
    await ctx.message.add_reaction('✅')


  @addrole.error
  async def addrole_error(ctx, error, amount = 3):
    if isinstance(error,commands.MissingRequiredArgument):
          await ctx.message.add_reaction('❌')
          await ctx.send(f"You're missing a required argument!")
          await ctx.send(f'Addrole example: *addrole [member] [role]')
          asyncio.sleep(3)
          await ctx.channel.purge(limit=amount)
    return
    if isinstance(error,commands.MissingAnyRole):
          await ctx.message.add_reaction('❌')
          await ctx.send(f'You lack permission to excute addrole!')
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

    return

	
  @commands.command(pass_context=True)
  @commands.has_permissions(kick_members=True)  
  async def removerole(self, ctx, member:discord.Member, *, role:discord.Role = None):
    await ctx.message.delete()
    await member.remove_roles(role)
    await ctx.send(f'{role} was taken from {member}')

  @removerole.error
  async def removerole_error(ctx, error, amount = 3):
    if isinstance(error,commands.MissingRequiredArgument):
          await ctx.message.add_reaction('❌')
          await ctx.send(f"You're missing a required argument!")
          await ctx.send(f'Removerole example: *removerole [member] [role]')
          asyncio.sleep(3)
          await ctx.channel.purge(limit=amount)
    return
    if isinstance(error,commands.MissingAnyRole):
          await ctx.message.add_reaction('❌')
          await ctx.send(f'You lack permission to excute removerole!')
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

    return

	
  @commands.command()
  @commands.has_permissions(administrator = True)
  async def banlist(self,ctx):
    bans = await ctx.guild.bans()
    loop = [f"{u[1]} ({u[1].id})" for u in bans]
    _list = "\r\n".join([f"[{str(num).zfill(2)}] {data}" for num, data in         enumerate(loop, start=1)])
    await ctx.send(f"```ini\n{_list}```")


  @commands.command()
  @commands.has_permissions(kick_members=True)  
  async def softban(self, ctx, member: discord.Member, reason):
    embed=discord.Embed(title="Softban", description="You have been removed from {ctx.guild.name} for {reason}. Please understand that you have violated our rules and you have faced punishment for it. Thank you for understanding why and accepting our punishment.", color=0xf8f6f6)
    embed.set_author(name="HawkEye ",     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160%22")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160%22")
    embed.set_footer(text="HawkEye Ban Services")
    await ctx.send(embed=embed)
    await member.send(embed = embed)
    await member.ban(reason=reason)
    await ctx.message.add_reaction('✅')
    await member.unban(reason=reason)



		

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def say(ctx, *, text):
    
    
    embed = discord.Embed(
          description = f'`{text}`',

          colour = discord.Color.green()

        )
    await ctx.send(embed=embed)



  @commands.command(aliases= ['purge','delete'])
  @commands.has_permissions(manage_messages=True)
  async def clear(self, ctx, int): # Set default value as None
            await ctx.channel.purge(limit=int)
            await ctx.send(f'Cleared {int} messages.')


  @commands.command(aliases= ['springcleaning','channelpurge'])
  @commands.has_role('HawkEye | Director')
  async def fullclear(ctx, channel: discord.TextChannel = None):
    nuke_channel = discord.utils.get(ctx.guild.channels, name=channel.name)

    if nuke_channel is not None:
        new_channel = await nuke_channel.clone(reason="Has been Nuked!")
        await nuke_channel.delete()
        await new_channel.send("This channel has been clear of **all messages**.")
        await ctx.send("Nuked the Channel sucessfully!")

    else:
        await ctx.send(f"No channel named {channel.name} was found!")

  @fullclear.error
  async def fullclear_error(ctx, error, amount = 3):
      if isinstance(error,commands.MissingAnyRole):
          await ctx.message.add_reaction('❌')
          await ctx.send(f'You lack permission to use this command.')
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)

      return
      if isinstance(error,commands.MissingRequiredArgument):
          await ctx.message.add_reaction('❌')
          await ctx.send(f"You're missing the channel name!")
          time.sleep(3) 
          await ctx.channel.purge(limit=amount)


async def setup(bot):
    await bot.add_cog(Moderation(bot))
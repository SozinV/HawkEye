import discord
import random
import asyncio
import os
from discord.ext import commands
from discord import utils
from discord import app_commands

class blank(commands.Cog):
  def __init__(self, client):
    self.client = client




    @commands.command()
    async def test(self, ctx):
      await ctx.send("test")

async def setup(bot):
    await bot.add_cog(blank(bot))
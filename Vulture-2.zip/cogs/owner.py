import discord
import random
import asyncio
import os
from discord.ext import commands
from discord import utils
from discord import app_commands

class OwnerCommands(commands.Cog):
  def __init__(self, client):
    self.client = client





async def setup(bot):
    await bot.add_cog(OwnerCommands(bot))
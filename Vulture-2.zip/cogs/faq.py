import discord
import random
import asyncio
import os
from discord.ext import commands
from discord import utils
from discord import app_commands

class faq(commands.Cog):
  def __init__(self, client):
    self.client = client


    @client.listen('on_messsage')
    async def on_message(message):
      lookout = ['version']
      for word in lookout:
        if word in message.content:
          await message.add_reaction("🦅")
          embed=discord.Embed(title="Verison ", description=f"Hello, {message.author.mention}. Want to know Vulture's version? Well our current version is V.2102. Don't what that means? Well don't worry, we got you covered.", color=0xf8f6f6)
          embed.add_field(name="Explation", value="V.2102 means Vultures current version. ", inline=False)
          embed.add_field(name="First 2 meaning", value="The first 2 in `V.2102` means Discord Python's version. Vulture currently uses 2.0 which is the stable ahpla version of Discord Python.", inline=False)
          embed.add_field(name="The 10 meaning", value="The 10 meaning is what level update it is. The 10 means the version release Vulture is. So on a 2.0 rewrite of Vulture it would be `V.2202`.", inline=False)
          embed.add_field(name="The last 2 meaning", value="The last 2 meaning what number update it is. The current version is 2.", inline=False)
          embed.set_footer(text="*help for more information on commands | V.2202")
          await message.reply(embed=embed)


    @client.listen('on_message')
    async def on_message(message):
      cool = ['Is Sozin cool?','is sozin cool?']
      for cool in cool:
        if cool in message.content:
          await message.reply("No.")
          return

          

    #@client.listen('on_message')
    async def on_message(message):
      partner = ['partner','Partnership']
      for partner in partner:
        if partner in message.content:
          await message.add_reaction("🤝")
          embed=discord.Embed(title="Partner Ship", description="Interested in partnering? Well if you are please message <@!460543691703189514> for more details about it.", color=0xebe5e5)
          embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/980248069771784212/980958014750216192/unknown.png")
          embed.add_field(name="Requirements", value="Member Count Must be above 25 people.", inline=False)
          embed.add_field(name="Other Requirements", value="Any more requirements will be said within dms.", inline=True)
          embed.set_footer(text="*help for more information about commands.")
          await message.reply(embed=embed)








async def setup(bot):
    await bot.add_cog(faq(bot))
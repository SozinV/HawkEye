import discord
import random
import asyncio
import os
from discord.ext import commands
from discord import utils


class Security(commands.Cog):
  def __init__(self, client):
    self.client = client


  @commands.command()
  @commands.has_any_role("HawkEye  | Moderator","HawkEye  |  Developer","HawkEye | Admin","HawkEye | Management","HawkEye | Director")
  async def alert(self, ctx, reason):
    embed=discord.Embed(title="Alert", description=f"A user has issued a alert command. Please respond as soon as possible. Member is: {ctx.author.mention} Reason is: {reason}", color=0xffffff)
    embed.set_author(name="HawkEye", 
    url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160", 
    icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_footer(text="HawkEye Services")

    channel = discord.utils.get(ctx.guild.channels, name="🔐・bot-logs")
    await channel.send(embed=embed)
    await ctx.message.add_reaction('✅')
    await ctx.channel.set_permissions(ctx.guild.default_role,send_messages=False)
    embed=discord.Embed(title="Lockdown", description="🔒 This channel is now in lockdown. Please wait until further notice from management when you're prohibited to speak again.", color=0xffffff)
    embed.set_author(name="HawkEye", 
    url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160", 
    icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_footer(text="HawkEye Services")
    await ctx.send(embed=embed)
    print('Alert Issue Correct')
    embed2=discord.Embed(title="Alert", description=f"Alert has been issued by {ctx.author.mention} for {reason}. Guild is on lock down so please respond as fast as possible.", color=0xffffff)
    embed2.set_author(name="Vulture", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed2.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed2.add_field(name="Reason:", value=f"Reason: {reason}", inline=True)
    embed2.add_field(name="Issuer", value=f"Issuer: {ctx.author.mention}", inline=True)
    embed2.set_footer(text="HawkEye Services")
    owner = self.get_user(460543691703189514)
    dm_channel = await owner.create_dm()
    await dm_channel.send(embed=embed2,tts=True)

  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(manage_channels = True)
  async def lockdown(self, ctx):
    await ctx.message.add_reaction('✅')
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
    embed=discord.Embed(title="Lockdown",                description=f"This channel has been placed on lockdown. Please wait until a highup unlocks the server.🔒", color=0xffffff)
    embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_footer(text="HawkEye Services")
    await ctx.send(embed=embed)

  
  
  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  @commands.has_permissions(manage_channels = True)
  async def unlock(self, ctx):
    await ctx.message.add_reaction('✅')
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
    embed=discord.Embed(title="Lockdown",                description="This server has been unlocked. Feel free to begin messaging again.🔓", color=0xffffff)
    embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_footer(text="HawkEye Services")
    await ctx.send(embed=embed)
		
    overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
    for channel in ctx.guild.text_channels:
      ava = discord.utils.get(channel.guild.categories, name="💬・general")
      ava = discord.utils.get(channel.guild.categories, name="🌎・images")
      ava = discord.utils.get(channel.guild.categories, name="🤖・bot-commands")
      chat = discord.utils.get(channel.guild.categories, id=905208888540926033)
      if channel.category is ava:
        pass
      else:
        if channel.category is chat:
           mbed = discord.Embed(
           title = 'Unlockdown!',
           description = f"The discord has been unlocked. Thank you for your patiecne and you may resume converstation.",
           color=0x12db2a
         )
           await channel.send(embed=mbed)
    await ctx.author.send(f'{ctx.guild.name} has been unlocked')


  @alert.error
  async def alert_error(ctx, error, amount = 3):
    if isinstance(error,commands.MissingAnyRole):
      await ctx.message.add_reaction('❌')
      await ctx.send(f'You lack permission to use this command.')
      asyncio.sleep(3) 
      await ctx.channel.purge(limit=amount)
    if isinstance(error,commands.MissingRequiredArgument):
        await ctx.message.add_reaction('❌')
        await ctx.send(f"You need to enter a reason!")
        asyncio.sleep(3) 
        await ctx.channel.purge(limit=amount)
    return



async def setup(bot):
    await bot.add_cog(Security(bot))
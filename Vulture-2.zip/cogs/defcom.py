import discord
import random
import asyncio
import os
import aiohttp
from discord.ext import commands
from discord.ext.commands import has_role
from itertools import cycle
import sqlite3
import json
import time
import js
import configs
from urllib.parse import urlparse
from discord import utils
import config
from dotenv import load_dotenv
import datetime

class Defcom(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def defcom(self, ctx,level: int):
    await self.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name= f" Defcom Level: {level}"))
    embed=discord.Embed(title="Defcom", description=f"Defcom level {level} has been set in place by {ctx.author.mention}. Please watch out for a possible attack and contact management for suspicious activity.", color=0xff0000)
    embed.set_author(name="HawkEye | Defcom System",
   icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Defcom Level:", value=f"Defcom Level: {level}", inline=True)
    embed.set_footer(text="HawkEye Services")
    await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Defcom(bot))
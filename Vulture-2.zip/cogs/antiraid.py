import discord
from discord.ext import commands
import os
import random
from random import choice
import asyncio
from discord.ext.commands import has_permissions, MissingPermissions
from discord.ext.commands import has_role
import time
import datetime
from datetime import datetime
import typing
import json




class messages(commands.Cog):
  def __init__(self, client):
    self.client = client




    anti_add = 'off'
    @client.listen('on_message')
    async def on_message(message):
      if message.author.id ==  925216549063774269 or message.author.id == 681238160126246972 or message.author.id == 913826764738936923:
        return
      filtered_words = ["discord.gg", "https://discord.gg/", 'NIGGER', 'nigger','Nigger','nIgGeR','NiGgEr','NIGger','nigGER']
      for word in filtered_words:
        if word in message.content:
          await message.delete()
          embed=discord.Embed(title="Warning",         description="You have been warned by automod for sending invite links. Please do not send a invite link again or you will face punishment. ", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_footer(text="HawkEye Automod Services")
          await message.author.send(embed=embed)
          embed=discord.Embed(title="Warning", description=f"A user has been warned for sending invite links in {message.channel.name}.", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.add_field(name="User:", value=f"User: {message.author.mention}", inline=False)
          embed.add_field(name="Invite Link:", value=f"Invite Link: {message.content}", inline=False)
          embed.set_footer(text="HawkEye Automod Services")
          log = discord.utils.get(message.guild.channels, name="🔐・bot-logs")
          await log.send(embed=embed)
          return

    @commands.command()
    async def anti_add(self, ctx):
      global anti_add
      if anti_add == 'off':
        anti_add = 'on'
        await ctx.send('Ads Detector has been Enabled.')
        return anti_add

      else:
        anti_add = 'off'
        await ctx.send('Ads Detector has been Disabled.')
        return anti_add


    


    

    @client.listen('on_message')
    async def on_message(message):
      filtered_words = ['https://','http://']
      for word in filtered_words:
        if word in message.content:
          await message.delete()
          embed=discord.Embed(title="Warning",         description="You have been warned by automod for sending website links. Please do not send a invite link again or you will face punishment. ", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_footer(text="HawkEye Automod Services")
          await message.author.send(embed=embed)
          embed=discord.Embed(title="Warning", description=f"A user has been warned for sending website links in {message.channel.name}.", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.add_field(name="User:", value=f"User: {message.author.mention}", inline=False)
          embed.add_field(name="Web Link:", value=f"Web Link: {message.content}", inline=False)
          embed.set_footer(text="HawkEye Automod Services")
          log = discord.utils.get(message.guild.channels, name="🔐・bot-logs")
          await log.send(embed=embed)
          return



    

    @client.listen('on_message')
    async def on_message(message):
      filtered_words = ['pornhub.com','xvideos.com','redgifs.com']
      for word in filtered_words:
        if word in message.content:
          await message.delete()
          embed=discord.Embed(title="Warning",         description="You have been caught sending pornography websites within this guild. This is your last warning, if you are caught again you will be punished.", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_footer(text="HawkEye Automod Services")
          await message.author.send(embed=embed)
          embed=discord.Embed(title="AntiNudity Warning", description=f"A user has been warned for sending pornograhpy links in {message.channel.name}.", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.add_field(name="User:", value=f"User: {message.author.mention}", inline=False)
          embed.add_field(name="Web Link:", value=f"Pornography Web Link: {message.content}", inline=False)
          embed.set_footer(text="HawkEye Automod Services | AntiNudity V1")
          log = discord.utils.get(message.guild.channels, name="🔐・bot-logs")
          await log.send(embed=embed)
          return



    @client.listen('on_message')
    async def on_message(message):
      filtered_words = ['imgur.com',]
      for word in filtered_words:
        if word in message.content:
          embed=discord.Embed(title="AntiNudity Warning", description=f"Possible NSFW posts are being made in {message.channel.name}.", color=0xffffff)
          embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.add_field(name="User:", value=f"User: {message.author.mention}", inline=False)
          embed.add_field(name="Web Link:", value=f"Posible Pornography Web Link: {message.content}", inline=False)
          embed.set_footer(text="HawkEye Automod Services | AntiNudity V1")
          log = discord.utils.get(message.guild.channels, name="🔐・bot-logs")
          await log.send(embed=embed)
          return

    
async def setup(bot):
    await bot.add_cog(messages(bot))
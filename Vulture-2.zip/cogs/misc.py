import discord
import random
import asyncio
import os
import aiohttp
from discord.ext import commands
from discord.ext.commands import has_role
from itertools import cycle
import sqlite3
import json
import datetime
from datetime import time
import time
import js
import configs
from urllib.parse import urlparse
from discord import utils
import config
from dotenv import load_dotenv
import datetime
from datetime import datetime
datetime.utcnow()
import DiscordUtils
from datetime import datetime,timezone
now_utc = datetime.now(timezone.utc)
datetime.now(timezone.utc).timestamp() * 1000


class Misc(commands.Cog):
  def __init__(self, client):
    self.client = client




  @commands.command()
  @commands.cooldown(1, 30, commands.BucketType.user)
  async def avatar(ctx, *,  avamember : discord.Member=None):
    userAvatarUrl = avamember.avatar_url
    await ctx.send(userAvatarUrl)




  @commands.command(name="userinfo")
  @commands.cooldown(1, 30, commands.BucketType.user)
  async def userinfo(self, ctx, user:discord.Member=None):
    await ctx.message.add_reaction('✅')
    if user==None:
        user=ctx.author

    rlist = []
    for role in user.roles:
      if role.name != "@everyone":
        rlist.append(role.mention)

    b = ", ".join(rlist)


    embed = discord.Embed(colour=0xffffff,timestamp=ctx.message.created_at)

    embed.set_author(name=f"User Info - {user}",icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160"),
    embed.set_thumbnail(url=user.display_avatar),
    embed.set_footer(text=f'Requested by - {ctx.author}',
  icon_url=user.avatar)

    embed.add_field(name='ID:',value=user.id,inline=False)
    embed.add_field(name='Name:',value=user.display_name,inline=False)
    date_format = "%a, %d %b %Y %I:%M %p"
    embed.add_field(name="Joined", value=user.joined_at.strftime(date_format))
    members = sorted(ctx.guild.members, key=lambda m: m.joined_at)
    embed.add_field(name="Join position", value=str(members.index(user)+1))
    embed.add_field(name="Registered", value=user.created_at.strftime(date_format))
    if len(user.roles) > 1:
        role_string = ' '.join([r.mention for r in user.roles][1:])

  
 
    embed.add_field(name='Bot?',value=user.bot,inline=False)

    embed.add_field(name=f'Roles:({len(rlist)})',value=''.join([b]),inline=False)
    embed.add_field(name='Top Role:',value=user.top_role.mention,inline=False)
    perm_string = ', '.join([str(p[0]).replace("_", " ").title() for p in user.guild_permissions if p[1]])
    embed.add_field(name="Guild permissions", value=perm_string, inline=False)
    embed.set_footer(text='ID: ' + str(user.id))
    await ctx.send(embed=embed)

  @commands.command()
  async def checkguilds(self, ctx, member:discord.Member=None):
    if member is None:
      member = ctx.author
    await ctx.message.add_reaction('✅')
    mbed = discord.Embed(title=f"{member.name}'s Guilds", description=f" ", color=0x51b5d8)
    for guild in self.guilds:
        if member in guild.members:
          mem = guild.get_member(member.id)
          mbed.add_field(name=guild.name, value=f"`{mem.display_name}` | Top Role = *{mem.top_role.name}*", inline=False)
    await ctx.author.send(embed=mbed)

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def setuplog(self, ctx):
        await ctx.send('Start setup? Yes or No?')
        msg = await self.wait_for('message', check=lambda           message:message.author == ctx.author and message.channel.id == ctx.channel.id)
        if msg.content in ("y", "yes"):
          await ctx.send("Setup initiated")
          await ctx.channel.send('Setting up...')
          await asyncio.sleep(3)
          bot = await ctx.guild.create_category(name='🔐・HawkEye')
          botlog=await ctx.guild.create_text_channel(name="🔐・bot-logs",category=bot)
          await botlog.set_permissions(ctx.guild.default_role, read_messages=False,send_messages = False, add_reactions = False)
          embed=discord.Embed(title="Finished", description="We finished up the logging for you! If you want to edit anything please use the command *changelog but beside that you're ready to go!", color=0xf4f0f0)
          embed.set_author(name="HawkEye Setup Features",                     icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          embed.set_footer(text="HawkEye Logging Setup")
          await ctx.author.send(embed=embed)

  @commands.command()
  async def helper(self, ctx):
    embed1=discord.Embed(title="Help", description=f"Hello {ctx.author.mention}!", color=0xffffff)
    embed1.add_field(name="Support", value="If you need more help please join our server at https://discord.gg/FDQjZRGDAk", inline=False)
    embed1.add_field(name="Who am I?", value="I am Vulture created by <@460543691703189514>. I am a powerful multifunction bot that can help make your life easier. We have a lot of moderation features and fun commands.", inline=False)
    embed1.add_field(name="What's next?", value="Check out our commands by using the dropdown modules below!", inline=False)
    embed2 = discord.Embed(color=ctx.author.color).add_field(name="🔨 Moderation Commands", value="Page 2")
    embed3 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 3")
    embed4 = discord.Embed(color=ctx.author.color).add_field(name="Hoae Page", value="Ho2e Page")
    embed5 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 2")
    embed6 = discord.Embed(color=ctx.author.color).add_field(name="Example", value="Page 3")
    paginator = DiscordUtils.Pagination.CustomEmbedPaginator(ctx, remove_reactions=True)
    paginator.add_reaction('⏮️', "first")
    paginator.add_reaction('⏪', "back")
    paginator.add_reaction('🔐', "lock")
    paginator.add_reaction('⏩', "next")
    paginator.add_reaction('⏭️', "last")
    embeds = [embed1, embed2, embed3]
    await paginator.run(embeds)

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def oauth2(self, ctx):
      await ctx.message.add_reaction('✅')
      await ctx.send(f"{ctx.message.author.mention}, check your DM's!")
      await ctx.author.send("Please enter the password to acceess my Oauth2 invite links.")

      def check(m):
        return ctx.author == m.author and isinstance(m.channel, discord.DMChannel) # Check that it is a DM channel
      try:
          test = await self.wait_for('message', check=check, timeout=100) # We wait 100 seconds for a user response/message in the DMs
          if test.content == "SozinIsCool9999": # Content can be changed to whatever you want
            await ctx.author.send("Correct password, heres my invite link!.")
            embed=discord.Embed(title="Oauth2", description="Here's all my Oauth2 Links", color=0xf4f0f0)
            embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
            embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
            embed.add_field(name="Vulture #1", value="https://discord.com/api/oauth2/authorize?client_id=905615521049882625&permissions=8&scope=bot", inline=False)
            embed.add_field(name="Vulture #2 *Current Client*", value="https://discord.com/api/oauth2/authorize?client_id=907008133619126343&permissions=8&scope=bot", inline=False)
            embed.add_field(name="Ticket Master", value="https://discord.com/api/oauth2/authorize?client_id=885743244095397939&permissions=8&scope=bot", inline=False)
            embed.add_field(name="Vulture AntiRaid", value="https://discord.com/api/oauth2/authorize?client_id=906985209554141225&permissions=8&scope=bot", inline=False)
            embed.set_footer(text="HawkEye Oauth2")
            await ctx.author.send(embed=embed)

          else:
            await ctx.author.send("Wrong password, run the command again!")
      except asyncio.TimeoutError:
        await ctx.author.send("The time was not enough? Alright.", delete_after=5)





async def setup(bot):
   await bot.add_cog(Misc(bot))
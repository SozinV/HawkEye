#pip install -U git+https://github.com/Rapptz/discord.py#
#python -m pip install -U git+https://github.com/Rapptz/discord-ext-menus#
import discord
import asyncio
import os
from discord.ext import commands
import json
import time
import psutil

from discord import app_commands



MY_GUILD = discord.Object(id=980565520233418772)  # replace with your guild id



class MyClient(discord.Client):
    def __init__(self, *, intents: discord.Intents):
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)
    async def setup_hook(self):
        # This copies the global commands over to your guild.
        self.tree.copy_global_to(guild=MY_GUILD)
        await self.tree.sync(guild=MY_GUILD)


def get_prefix(client, message): ##first we define get_prefix
    with open('prefixes.json', 'r') as f: ##we open and read the prefixes.json, assuming it's in the same file
        prefixes = json.load(f) #load the json as prefixes
    return prefixes[str(message.guild.id)] #recieve the prefix for the guild id given
def get_muterole(message):
    with open("muterole.json", 'r') as f:
        mute = json.load(f)
    role = discord.utils.get(message.guild.roles, name=mute[str(message.guild.id)])
    return role.id


def check_if_it_is_me(ctx):
    return ctx.message.author.id == 460543691703189514


intents = discord.Intents.default()
intents.members = True
intents.message_content = True
client = commands.Bot(command_prefix=(get_prefix), intents=intents, sync_commands=True)

@client.event
async def on_ready():
  for guild in client.guilds:
      print(f"{guild.name} | {guild.id}")

subclient = MyClient(intents=intents)

def get_prefix(client, message): ##first we define get_prefix
    with open('prefixes.json', 'r') as f: ##we open and read the prefixes.json, assuming it's in the same file
        prefixes = json.load(f) #load the json as prefixes
    return prefixes[str(message.guild.id)]

    async def setup_hook(self):
        # This copies the global commands over to your guild.
        self.tree.copy_global_to(guild=MY_GUILD)
        await self.tree.sync(guild=MY_GUILD)





@client.tree.command()
async def hello(interaction: discord.Interaction):
    """Says hello!"""
    await interaction.response.send_message(f'Hi, {interaction.user.mention}')

@client.command(aliases=["mc"])
async def member_count(ctx):

    a=ctx.guild.member_count
    b=discord.Embed(title=f"members in {ctx.guild.name}",description=a,color=discord.Color((0xffff00)))
    await ctx.send(embed=b)


@client.command()
async def embededit(ctx):
  first_embed = discord.Embed(title='embed 1')
  new_embed = discord.Embed(title='embed 2')

# send a first message with an embed
  msg = await ctx.send(embed=first_embed)

# edit the embed of the message
  await msg.edit(embed=new_embed)


@client.command()
@commands.has_permissions(administrator=True)
async def verify(ctx, *, user: discord.User):
    await ctx.message.add_reaction('✅')
    await ctx.send(f"{ctx.message.author.mention}, check your DM's!")
    embed=discord.Embed(title="Verifcation ", description="Please verify that your human by responding with the integer provided down bellow.", color=0xe8e3e3)
    embed.add_field(name="Why is this happening?", value=f"This will most likely happen if {ctx.guild.name} gets placed in Anti-Raid or it's threshold gets reached. Don't worry if you get it wrong you won't get banned. Or will you?", inline=False)
    embed.set_footer(text="Please verify by saying 'I am Human'.")
    await user.send(embed=embed)



class Dropdown(discord.ui.Select):
    def __init__(self):

        # Set the options that will be presented inside the dropdown
        options = [
            discord.SelectOption(label='Mute Role', description='Ser your mute role', emoji='🔇'),
            discord.SelectOption(label='Set Logging', description='Set the channel you want to log events', emoji='📜'),
            discord.SelectOption(label='Prefix', description='Config Options for Vulture', emoji='🔣', value = "prefix"),
            discord.SelectOption(label='Cancel', description='Cancel', emoji='❌'),
        ]

        super().__init__(placeholder='Chose what you want to configure.', min_values=1, max_values=1, options=options)
    async def callback(self, interaction: discord.Interaction):

        if self.values[0] == "prefix":
            await interaction.response.send_message(f'Chose your prefix. *Heads up! Please only use a symbol.* Please reply to this mesage with your prefix.')
            msg = await self.wait_for('message', check=lambda message:message.author == self.context.author and message.channel.id == self.context.channel.id)
        if msg.content in ("y", "yes"):
            await interaction.message.send("Setup initiated")


class DropdownView(discord.ui.View):
    def __init__(self):
        super().__init__()

        # Adds the dropdown to our view object.
        self.add_item(Dropdown())





      
@client.command()
async def config(ctx):
    """Sends a message with our dropdown containing colours"""

    # Create the view containing our dropdown
    view = DropdownView()

    # Sending a message containing our view
    await ctx.send('Chose what to configure about your guild:', view=view)



class Dropdown(discord.ui.Select):
	def __init__(self, ctx, options):
		super().__init__(placeholder="Select a category...", min_values=1, max_values=1, options=options)
		self.invoker = ctx.author

	async def callback(self, interaction: discord.Interaction):
		if self.invoker == interaction.user:
			index = self.view.find_index_from_select(self.values[0])
			if not index: index = 0
			await self.view.set_page(index, interaction)
		else:
			await interaction.response.send_message("❌ Hey it's not your session !", ephemeral=True)





@client.command()
async def test(ctx):
    """Sends a message with our dropdown containing colours"""

    # Create the view containing our dropdown
    view = Dropdown()

    # Sending a message containing our view
    await ctx.send('Chose what to configure about your guild:', view=view)



class HelpDropdown(discord.ui.Select):
    def __init__(self):
        options = [
                discord.SelectOption(label='Moderation Commands', description='Moderation Commands',emoji = '🔨', value="value1"),
                discord.SelectOption(label='Misc Commands', description="Misc Commands",emoji = '❔', value="value2"),
								discord.SelectOption(label='Ticket Commands', description="Ticket Commands",emoji = '🎫', value="tic"),		
                discord.SelectOption(label='Economy and Games', description='Economy and Games',emoji = '💵', value='ecom'),
                discord.SelectOption(label='Owner Commands', description='Guild Owner Commands',emoji ='👑', value='king'),
                discord.SelectOption(label='Music Commands', description='Music Commands',emoji = '🎵', value = "music"),
                discord.SelectOption(label='Config Commands', description='Configuration Commands',emoji = '⚙️', value = "config"),
                discord.SelectOption(label='Cancel', description="Cancel your decision",emoji = '❌', value = "cancel")]
        def add_buttons(self):
          self.startB = discord.Buttons(label="<<", style=discord.ButtonStyle.grey, command=self.set_page, args=0, ctx = self.ctx)
          self.backB = discord.Buttons(label="Back", style=discord.ButtonStyle.blurple, command=self.to_page, args=-1, ctx = self.ctx)
          self.nextB = discord.Buttons(label="Next", style=discord.ButtonStyle.blurple, command=self.to_page, args=+1, ctx = self.ctx)
          self.endB = discord.Buttons(label=">>", style=discord.ButtonStyle.grey, command=self.set_page, args=len(self.options)-1, ctx = self.ctx)
          self.quitB = discord.Buttons(label="Quit", style=discord.ButtonStyle.red, command=self.quit, ctx = self.ctx)
          buttons = [self.startB, self.backB, self.nextB, self.endB, self.quitB]
          for button in buttons: self.add_item(button)
          return buttons
      


        super().__init__(placeholder='Chose what you need help with.', options=options)
    async def callback(self, interaction: discord.Interaction):
            if self.values[0] == "value1":
              embed=discord.Embed(title="Moderation Commands", description="All of Vultures moderation commands.", color=0xebe5e5)
              embed.add_field(name="Addrole", value="*addrole <member> <role>", inline=False)
              embed.add_field(name="Removerole", value="*removerole <member> <role>", inline=False)
              embed.add_field(name="Clear", value="*clear <int>", inline=False)
              embed.add_field(name="Kick", value="*kick <member> <reason>", inline=False)
              embed.add_field(name="Mute", value="*mute <member> <reason>", inline=False)
              embed.add_field(name="Unmute", value="*unmute <member>", inline=False)
              embed.add_field(name="Ban", value="*ban <member> <reason>", inline=False)
              embed.add_field(name="Unban", value="*unban <member>", inline=False)
              embed.add_field(name="Globalban", value="*globalban <member> <reason>", inline=False)
              embed.add_field(name="Unglobalban", value="*unglobalban <member>", inline=False)
              embed.add_field(name="Softban", value="*softban <member>", inline=False)
              embed.add_field(name="Voiceban", value="*voiceban <member>", inline=False)
              embed.add_field(name="Unvoiceban", value="*unvoiceban <member>", inline=False)
              embed.add_field(name="Setnick", value="*setnick <member> <nickname>", inline=False)
              embed.add_field(name="Slowmod", value="*slowmode <time>", inline=False)
              embed.add_field(name="Rolestrip", value="*rolestrip <member>", inline=False)
              await interaction.response.send_message(embed=embed),

            if self.values[0] == "value2":
                embed=discord.Embed(title="Misc Commands", description="All of Vultures misc commands.", color=0xebe5e5)
                embed.add_field(name="Avatar", value="*avatar <member>", inline=False)
                embed.add_field(name="Checkguilds", value="*checkguilds <member>", inline=False)
                embed.add_field(name="Helper", value="*helper", inline=False)
                embed.add_field(name="Ping", value="*ping", inline=False)
                embed.add_field(name="Setuplog", value="*setuplog", inline=False)
                embed.add_field(name="Userinfo", value="*userinfo", inline=False)
                await interaction.response.send_message(embed=embed)

            if self.values[0] == "config":
                embed=discord.Embed(title="Config Commands", description="All of Vultures config commands.", color=0xebe5e5)
                embed.add_field(name="Prefix", value="*prefix <prefix>", inline=False)
                embed.add_field(name="Change muted role", value="*changemute <role>", inline=False)
                embed.add_field(name="Change Log Channel", value="*changelog <log>", inline=False)
                await interaction.response.send_message(embed=embed)

            if self.values[0] == "ecom":
                await interaction.response.send_message(f'Uh oh seems like we ran into a problem. `ERROR CODE: 404`')


            if self.values[0] == "tic":
                await interaction.response.send_message(f'Uh oh seems like we ran into a problem. `ERROR CODE: 404`')

            if self.values[0] == "king":
                await interaction.response.send_message(f'Uh oh seems like we ran into a problem. `ERROR CODE: 404`')

            if self.values[0] == "music":
                embed=discord.Embed(title="Music Commands", description="All of Vultures music commaands.", color=0xffffff)
                embed.add_field(name="Play", value="*play {song}", inline=False)
                embed.add_field(name="Summon", value="*summon {channel}", inline=False)
                embed.add_field(name="Join", value="*join", inline=False)
                embed.add_field(name="Stop", value="*stop", inline=False)
                embed.add_field(name="Volume", value="*volume {int}", inline=False)
                embed.add_field(name="Now", value="*now", inline=False)
                embed.add_field(name="Pause", value="*pause", inline=False)
                embed.add_field(name="Resume", value="*resume", inline=False)
                embed.add_field(name="Skip", value="*skip", inline=False)
                embed.add_field(name="Queue", value="*queue", inline=False)
                embed.add_field(name="Shuffle", value="*shufle", inline=False)
                embed.add_field(name="Remove", value="*remove {int}", inline=False)
                embed.add_field(name="Loop", value="*loop", inline=False)
                await interaction.response.send_message(embed=embed)

																		
class HelpView(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.add_item(HelpDropdown())

class MyHelp(commands.HelpCommand):

  async def send_command_help(self, command):
        embed = discord.Embed(title=self.get_command_signature(command),  color=0xffffff)

        alias = command.aliases
        if alias:
            embed.add_field(name="Aliases", value=", ".join(alias), inline=False)

        channel = self.get_destination()
        await channel.send(embed=embed)
	
  async def send_bot_help(self, mapping):
    """Sends a message with our dropdown containing colours"""
    await self.context.message.add_reaction('✅')
    embed=discord.Embed(title=f"Help", color=0xffffff)
    prefix = "*"
    embed.description = ("""
            Hello! Welcome to the help page.
            Use f"*help category" for more info on a category.
            Use f"*help category" for more info on a category.
            Use the dropdown menu below to select a category.
            *Rember the prefix is the guild prefix!*
        """)
        

    embed.add_field(name="Support", value="If you need more help please join our server at https://discord.gg/FDQjZRGDAk", inline=False)
    embed.add_field(name="Who am I?", value="I am Vulture created by <@460543691703189514>. I am a powerful multifunction bot that can help make your life easier. We have a lot of moderation features and fun commands. I have been running since <t:1652043073>!", inline=False)
    embed.add_field(name="Prefix", value="Vulture's default prefix is `*`", inline=False)
    embed.add_field(name="What's next?", value="Check out our commands by using the dropdown modules below!", inline=False)
    embed.set_footer(text="*help for more information about a command | V.1102")
    # Create the view containing our dropdown
    ebed = embed=embed
    await self.context.send(embed=ebed)
    view = HelpView()

    # Sending a message containing our view
    await self.context.send(view=view)


		
#client.help_command = MyHelp()



import datetime
			
@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def ping(ctx):
    start_time = time.time()
    current_time = time.time()
    difference = int(round(current_time - start_time))
    text = str(datetime.timedelta(seconds=difference))
    await ctx.message.add_reaction('✅')
    embed=discord.Embed(title="Network Status", color=0xffffff)
    embed.set_author(name="HawkEye",       icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Ping:", value=f"\nLatency: {round(client.latency * 1000)}ms", inline=True)
    embed.add_field(name="Status:", value=f"Status: Online", inline=True)
    count = len(client.guilds)
    embed.add_field(name="Uptime", value=f"Client Uptime: {text}", inline=False)
    embed.add_field(name="Server Count", value=f"Guild Count: {count}", inline=False)
    embed.add_field(name="HawkEye API Status:", value=f"I don't know lmao", inline=True)

    embed.set_footer(text="HawkEye Services | HawkEye API: Server Found and responsive* ")
    await ctx.send(embed=embed)





@client.event
async def on_guild_join(guild): #when the bot joins the guild
    with open('prefixes.json', 'r') as f: #read the prefix.json file
        prefixes = json.load(f) #load the json file

    prefixes[str(guild.id)] = '*'#default prefix

    with open('prefixes.json', 'w') as f: #write in the prefix.json "message.guild.id": "bl!"
        json.dump(prefixes, f, indent=4) #the indent is to make everything look a bit neater
        owner = guild.owner_id
    embed=discord.Embed(title="Setup", description=f"Hello <@!{owner}>! Here at HawkEye we are happy that you are using our client. While you read through this logging is being setup for you and we we're at it why not change the prefix?", color=0xf8f6f6)
    embed.add_field(name="Prefix", value="Your guild default prefix is `*` but if you want to change it you can execute *prefix `{your prefix}`.", inline=False)
    embed.add_field(name="Error Handeling ", value="How Vulture's error handling works is by using HTTP error codes. Most error codes match up with the problem . Such as `404` for a command thats not found.", inline=False)
    embed.add_field(name="Logging", value="Logging has been setup for you under the HawkEye category. With the next Vulture update it will provide the custom logging command. So you can change what channel will log every event. ", inline=True)
    embed.set_footer(text="*help for more information on commands")
    await guild.owner.send(embed=embed)
    await guild.delete_category("🔐・HawkEye")
    await guild.delete_text_channel("🔐・HawkEye")
    manage = await guild.create_category("🔐・HawkEye")
    time.sleep(2)
    await guild.create_text_channel("🔐・bot-logs", category=manage)


@client.event
async def on_guild_remove(guild): #when the bot is removed from the guild
    with open('prefixes.json', 'r') as f: #read the file
        prefixes = json.load(f)

    prefixes.pop(str(guild.id)) #find the guild.id that bot was removed from

    with open('prefixes.json', 'w') as f: #deletes the guild.id as well as its prefix
        json.dump(prefixes, f, indent=4)
      
@client.command(pass_context=True)
@commands.has_permissions(administrator=True) #ensure that only administrators can use this command
async def prefix(ctx, prefix): #command: bl!changeprefix ...
    with open('prefixes.json', 'r') as f:
        prefixes = json.load(f)

    prefixes[str(ctx.guild.id)] = prefix

    with open('prefixes.json', 'w') as f: #writes the new prefix into the .json
        json.dump(prefixes, f, indent=4)

    await ctx.message.add_reaction('✅')

@prefix.error
async def prefix(ctx, error):
   if isinstance(error, commands.MissingPermissions):
    await ctx.author.send("You lack permission to execute this command. `Error 401 Unauthorized`")
    await ctx.message.add_reaction('❌')
   elif isinstance(error, commands.MissingRequiredArgument):
    await ctx.author.send("Your request is unacceptable. Please finish with the correct argument`Error 405 Method Not Allowed`")
    await ctx.message.add_reaction('⚠️')







class Confirm(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.value = Confirm

    # When the confirm button is pressed, set the inner value to `True` and
    # stop the View from listening to more input.
    # We also send the user an ephemeral message that we're confirming their choice.
    @discord.ui.button(label='Confirm', style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('Cancelling', ephemeral=True)
        self.value = True


    # This one is similar to the confirmation button except sets the inner value to `False`
    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('Cancelling', ephemeral=True)
        self.value = False
        self.stop()







@client.command()
async def advanceban(ctx, *, member : discord.Member, reason=None):
    """Asks the user a question to confirm something."""
    embed=discord.Embed(title="Advance Ban", description=f"Hello, {ctx.author.mention}! Thank you for trying out our advance ban system. With this you can confirm you ban via discord's UI by pressing the confirm button", color=0xfafafa)
    embed.add_field(name="Ban Types", value="Globalban, Softban, Ban", inline=False)
    embed.set_footer(text="Do you want to continue?")
    view = Confirm()
    await ctx.send(embed=embed, view=view, ephemeral=True)
    await view.wait()
    if view.value is (Confirm):
      print("confirming...")
      await ctx.send("Confirming Ban...")
      embed1=discord.Embed(title="Banned", description=f"You have been banned from {ctx.guild.name} for {reason} by {ctx.author.mention}. Please understand the you have violated our rules and we have punished you. If you believe this is a mistake please contact support <@!460543691703189514>. Please and thank you.", color=0xffffff)
      embed1.set_author(name="HawkEye Services",icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed1.set_footer(text="HawkEye Services | Banned at:")
      await member.send(embed = embed1)
      await member.ban(reason=reason)
      await ctx.message.add_reaction('✅')
      embed=discord.Embed(title="Banned", description=f"User {member.mention} has been banned by {ctx.author}. ", color=0xffffff, timestamp=ctx.message.created_at)
      embed.set_author(name="HawkEye Services", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.add_field(name=f"User Banned", value=f"User Banned: {member.mention}", inline=False)
      embed.add_field(name=f"Moderator", value=f"Moderator: {ctx.author.mention}", inline=False)
      embed.set_footer(text=f"HawkEye Services | Member banned at: ")
      log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
      print("Ban Confirdmed")
			
    await view.wait()
    if view.value is None:
        print('Timed out...')
    elif view.value:
        print('Confirmed...')
    else:
        print('Cancelled...')







@client.command()
@commands.has_permissions(administrator = True)
async def devtemp(ctx):
    owner = client.get_user(460543691703189514)
    dm_channel = await owner.create_dm()
    await dm_channel.send("https://discord.new/7Gm8BvsRZpWq **Dev Server Template**",    
    tts=True)
    await ctx.message.add_reaction('✅')

@client.command()
@commands.has_permissions(administrator = True)
async def fivemtemp(self, ctx):
    owner = client.get_user(460543691703189514)
    dm_channel = await owner.create_dm()
    await dm_channel.send("https://discord.new/YQMxF2KpfwMg **Chill Server Template**",    
    tts=True)

@client.command()
@commands.has_permissions(administrator = True)
async def chilltemp(ctx):
    owner = client.get_user(460543691703189514)
    dm_channel = await owner.create_dm()
    await dm_channel.send("https://discord.new/YQMxF2KpfwMg **Chill Server Template**",    
    tts=True)
    await ctx.message.add_reaction('✅')

@chilltemp.error
async def removerole_error(ctx, error):
   if isinstance(error, commands.MissingPermissions):
    await ctx.author.send("You don't have permission for this template.")
    await ctx.message.add_reaction('❌')

@devtemp.error
async def removerole_error(ctx, error):
   if isinstance(error, commands.MissingPermissions):
    await ctx.author.send("You don't have permission for this template.")
    await ctx.message.add_reaction('❌')


# Cogs Loading and Commands #


@client.command()
@commands.check(check_if_it_is_me)
async def load(ctx, extension):
  await client.load_extension(f'cogs.{extension}')
  await ctx.message.add_reaction('✅')

@client.command()
@commands.check(check_if_it_is_me)
async def unload(ctx, extension):
  await client.unload_extension(f'cogs.{extension}')
  await ctx.message.add_reaction('✅')

@client.command()
@commands.check(check_if_it_is_me)
async def reload(ctx, extension):
  await client.unload_extension(f'cogs.{extension}')
  await client.load_extension(f'cogs.{extension}')
  await ctx.message.add_reaction('✅')

@unload.error
async def unload_error(ctx, error):
   if isinstance(error, commands.check_if_it_is_me):
    await ctx.author.send("You don't have permission to unload this extension.")
    await ctx.message.add_reaction('❌')

@reload.error
async def reload_error(ctx, error):
   if isinstance(error, commands.MissingPermissions):
    await ctx.author.send("You don't have permission to reload this extension.")
    await ctx.message.add_reaction('❌')

@load.error
async def load(ctx, error):
   if isinstance(error, commands.MissingPermissions):
    await ctx.author.send("You don't have permission for this to load")
    await ctx.message.add_reaction('❌')


	



@client.command()
@commands.has_permissions(administrator=True) 
async def changemute(ctx, *, role: discord.Role):
    with open("muterole.json", 'r') as f:
        admins = json.load(f)

    admins[str(ctx.guild.id)] = role.name

    with open("muterole.json", 'w') as f:
        json.dump(admins, f, indent=4)

    await ctx.send(f"Muted role changed to `{role.name}`")






async def load_extensions():
  for filename in os.listdir("./cogs"):
	  if filename.endswith(".py"):
		  await client.load_extension(f"cogs.{filename[:-3]}")
		  print(f"The cog {filename[:-3]}.py file has been loaded.")

async def load_other_extensions():
  for filename in os.listdir("./utils"):
	  if filename.endswith(".py"):
		  await client.load_extension(f"cogs.{filename[:-3]}")
		  print(f"The utils {filename[:-3]}.py file has been loaded.")



async def main():
    async with client:
        await load_extensions()
        await load_other_extensions()
        await client.start(os.getenv('TOKEN'))
my_secret = os.environ['TOKEN']
asyncio.run(main())

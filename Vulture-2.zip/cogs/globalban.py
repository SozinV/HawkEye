import discord
import random
import asyncio
import os
from discord.ext import commands
from discord import utils


class Globalban(commands.Cog):
  def __init__(self, client):
    self.client = client

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def globalban(self, ctx,*, user : discord.User = None, reason=None):
      await ctx.message.add_reaction('✅')
      embed=discord.Embed(title="Globalban", description="You have been removed from the community for violating our rules. Please understand that what you did was punishable by management. Our team wants everyone to have fun so please understand that in the future your ban may be removed if seems fit. ", color=0xffffff)
      embed.set_author(name="HawkEye",       icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_footer(text="HawkEye Services")
      await user.send(embed=embed)
      for guild in self.client.guilds:
        await guild.ban(user)
        embed=discord.Embed(title="Globalban", description=f"A user has been removed from the community for {reason}. ", color=0xffffff)
        embed.set_author(name="HawkEye",       icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.add_field(name="Moderator:", value=f"Moderator: {ctx.author.mention}", inline=False)
      embed.add_field(name="Reason:", value=f"Reason: {reason}", inline=True)
      embed.add_field(name="Member: ", value=f"Member: {user.mention}", inline=False)
      embed.set_footer(text="HawkEye Services")
      log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
      await log.send(embed=embed)

  
  @commands.command()
  @commands.has_permissions(administrator = True)
  async def unglobalban(self, ctx, user : discord.User):
    await ctx.message.add_reaction('✅')
    for guild in self.client.guilds:
      guild=ctx.guild
      await guild.unban(user=user)
      embed=discord.Embed(title="Globalban Removed", description=f"A members globalban has been revoked by {ctx.author.mention}. ", color=0xffffff)
      embed.set_author(name="HawkEye",       icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
      embed.add_field(name="Moderator:", value=f"Moderator:", inline=True)
      embed.add_field(name="Member:", value=f"Member:", inline=False)
      embed.set_footer(text="HawkEye Services")
      log = discord.utils.get(ctx.guild.text_channels, name="🔐・bot-logs")
      await log.send(embed=embed)

  @commands.command()
  @commands.has_permissions(administrator = True)
  async def globalkick(self, ctx, user : discord.User):
    for guild in self.client.guilds:
      await guild.kick(user)
      await ctx.send(f'{user.mention} has been globally kicked')
	




async def setup(bot):
    await bot.add_cog(Globalban(bot))
import os

clear = lambda: os.system('clear')

def install(package):
  os.system(f"poetry add {package}")


clear()
install('python3 -m pip install -U .[voice]')
install('git+https://github.com/Rapptz/discord.py')
install('python -m pip install -U git+https://github.com/Rapptz/discord-ext-menus')
clear()
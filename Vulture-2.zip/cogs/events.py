
import discord
import random
import asyncio
import os
import aiohttp
from discord.ext import commands
from discord.ext.commands import has_role
from itertools import cycle
import sqlite3
import json
import time
import js
import configs
from urllib.parse import urlparse
from discord import utils
import config
from dotenv import load_dotenv
import datetime

class main(commands.Cog):
  def __init__(self, client):
    self.client = client

  



  @commands.Cog.listener()
  async def on_member_update(self, before, after):
        channel = discord.utils.get(before.guild.channels, name="🔐・bot-logs")
        entry = [x async for x in after.guild.audit_logs(limit=1)][0]
        user = entry.user
        changed_role_set = set(before.roles) ^ set(after.roles)
        if len(changed_role_set) > 0:
          changed_role = next(iter(changed_role_set))
          embed=discord.Embed(title=f"Role Added/Removed", description="", color=0xffffff)
          embed.add_field(name="Role:", value=changed_role.mention,inline=False)
          embed.add_field(name= "User:" ,value=after.mention, inline=True)
          embed.add_field(name= "Moderator:" ,value=user.mention, inline=False) 
          embed.set_footer(text="HawkEye Services")
          embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
          await channel.send(embed=embed)


 # @commands.Cog.listener()
 # async def on_member_join(self, member):
    #welcome = discord.utils.get(member.guild.channels, name='👋・welcome')
    #log = discord.utils.get(member.guild.channels, name="🔐・bot-logs")	
    #embed=discord.Embed(title="Welcome", description=f"Hello, {member.mention} welcome to HawkEye Networks and Solutions. Please take a look in <#905209748977254450> and have fun!", color=0xffffff)
    #embed.set_author(name="HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    #embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    #embed.set_footer(text="HawkEye Services")
    #await welcome.send(embed=embed)
    #memberole = discord.utils.get(member.guild.roles, name="HawkEye | Member")
    #embed1=discord.Embed(title="Member Joined", description=f"Member has joined by the name of {member.mention}.", color=0xfaf9f9)
    #embed1.set_author(name="HawkEye Services",           icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    #embed1.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    #embed1.add_field(name="Member:", value=f"Member: {member.mention}", inline=False)
    #embed1.set_footer(text="HawkEye Logging")
    #await log.send(embed=embed1)

#entry = [x async for x in after.guild.audit_logs(limit=1)][0]
  
  @commands.Cog.listener()
  async def on_guild_channel_create(self, channel):
        log = discord.utils.get(channel.guild.channels, name="🔐・bot-logs")
        entry = [x async for x in guild.audit_logs(limit=1)][0]
        user = entry.user.id       
        embed=discord.Embed(title=f"Channel Created", description="", color=0x51b5d8)
        embed.add_field(name= "Name:" ,value=channel.name, inline=True)
        embed.add_field(name= "Creator:" ,value=user.name, inline=False)
        await log.send(embed=embed)
        return






  @commands.Cog.listener()
  async def on_guild_remove(guild): #when the bot is removed from the guild
    with open('prefixes.json', 'r') as f: #read the file
        prefixes = json.load(f)

    prefixes.pop(str(guild.id)) #find the guild.id that bot was removed from

    with open('prefixes.json', 'w') as f: #deletes the guild.id as well as its prefix
        json.dump(prefixes, f, indent=4)

		
  @commands.Cog.listener()
  async def on_guild_role_create(self, role):
		        role2 = discord.utils.get(role.guild.roles, name="Hawkeye™")
		        role1 = discord.utils.get(role.guild.roles, name="Hawkeye | Role Stripped")
		        log = discord.utils.get(role.guild.channels, name="🔐・bot-logs")
		        entry = list(await role.guild.audit_logs(limit=1).flatten())[0]
		        user = entry.user.id
		        member = role.guild.get_member(user)
		        if role2 in member.roles:
		          embed=discord.Embed(title=f"Role Created", description="", color=0x51b5d8)
		          embed.add_field(name= "Name:" ,value=role.name, inline=True)
		          embed.add_field(name="Color Code:", value=role.color, inline=False)
		          embed.add_field(name= "Creator:" ,value=member.name, inline=False)
		          await log.send(embed=embed)
		        else:
		          await member.edit(roles=[role1])
		          embed=discord.Embed(title=f"Member Role Stripped", description="", color=0x51b5d8)
		          embed.add_field(name= "Info:" ,value=f"{member.mention} was role stripped for unauthorized role creation.", inline=True)
		          await role.delete()
		          await log.send(embed=embed)
		          return
		
  @commands.Cog.listener()
  async def on_guild_role_delete(self, role):
		        role2 = discord.utils.get(role.guild.roles, name="Hawkeye™")
		        role1 = discord.utils.get(role.guild.roles, name="Hawkeye | Role Stripped")
		        log = discord.utils.get(role.guild.channels, name="🔐・bot-logs")
		        entry = list(await role.guild.audit_logs(limit=1).flatten())[0]
		        user = entry.user.id
		        member = role.guild.get_member(user)
		        if role2 in member.roles:
		          embed=discord.Embed(title=f"Role Deleted", description="", color=0x51b5d8)
		          embed.add_field(name= "Name:" ,value=role.name, inline=True)
		          embed.add_field(name="Color Code:", value=role.color, inline=False)
		          embed.add_field(name= "Admin:" ,value=member.name, inline=False)
		          await log.send(embed=embed)
		        else:
		          await member.edit(roles=[role1])
		          embed=discord.Embed(title=f"Member Role Stripped", description="", 											color=0x51b5d8)
		          embed.add_field(name= "Info:" ,value=f"{member.mention} was role stripped for 						unauthorized role deletion.\n *A new role has been created with the same 		color and 		name*.", inline=True)
		          await member.guild.create_role(name=role.name, color=role.color)
		          await log.send(embed=embed)
		          return
		

		
		
  @commands.Cog.listener()
  async def on_message_delete(self, message):
    embed = discord.Embed(title="{} deleted a message".format(message.author.name),
                          description="", color=0xffffff)
    embed.set_author(name=f"HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Message Content", value=f"{message.content}",
                    inline=False)
    embed.add_field(name="Message Channel", value=f"<#{message.channel.id}>",inline=True)
    log = discord.utils.get(message.guild.channels, name="🔐・bot-logs")
    await log.send(embed=embed)


  @commands.Cog.listener()
  async def on_message_edit(self, message_before, message_after):
    embed = discord.Embed(title="{} edited a message".format(message_before.author.name),
                          description="", color=0xffffff)
    embed.set_author(name=f"HawkEye", icon_url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.set_thumbnail(url="https://cdn.discordapp.com/avatars/905615521049882625/26d6d73bd826da3cec5609ed25dbb0ea.webp?size=160")
    embed.add_field(name="Message Before Edit", value=f"{message_before.content}",
                    inline=False),
    embed.add_field(name="Message Afer Edit", value=f"{message_after.content}",inline=False)
    embed.add_field(name="Message Channel", value=f"<#{message_after.channel.id}>",inline=False)
    log = discord.utils.get(message_before.guild.channels, name="🔐・bot-logs")
    await log.send(embed=embed)



async def setup(bot):
    await bot.add_cog(main(bot))